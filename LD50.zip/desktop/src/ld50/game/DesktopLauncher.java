package ld50.game;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import ld50.game.Main;
import ld50.game.util.Util;

// Please note that on macOS your application needs to be started with the -XstartOnFirstThread JVM argument
public class DesktopLauncher {
	public static void main (String[] arg) {
		Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
		Main main = new Main();
		
		//setting title
		config.setTitle(Util.window.title);
		
		//Setting size
		config.setWindowedMode((int)Util.window.size.getX(), (int)Util.window.size.getY());
		
		//setting FPS
		config.setForegroundFPS(60);
		config.setIdleFPS(30);
		
		//setting boolean variables
		config.setResizable(true); 

		new Lwjgl3Application(main, config);
	}
}
