package ld50.game.state;

import ld50.game.util.objects.GameObject;

public class ChaosCreature extends GameObject{

	//fields
	private int imageAnimation, imageSize;
	
	public ChaosCreature() {
		super();
		imageAnimation = (int)(Math.random() * 3);
		imageSize = 0;
		
	}
	
	//set charge
	public void setImageSize(int i) {imageSize = i % 4;}
	public void setAnimation(int i) {imageAnimation = i % 3;}

	//get
	public int getImageSize() {return imageSize;}
	public int getAnimation() {return imageAnimation;}
	
}
