package ld50.game.state;

/*** This class contains the current state of the multiverse*/
public class Background {

	private static final int STRAT_SCORE = 2023;
	
	//fields
	private float instability;
	private int furthestTime;
	
	//constructor
	public Background() {
		
		//setting default values
		instability = .1f;
		furthestTime = STRAT_SCORE;
	}
	
	/*** Get the instability of the multiverse*/
	public float getInstability() {return instability;}
	public int getFurthestTime() {return furthestTime;}
	
	/*** Adds to the instability of the multiverse*/
	public void addInstability(float f) {instability += f;}
	public void setFurthestTime(int nodes) {furthestTime = STRAT_SCORE + nodes / 10;}
	
	
}
