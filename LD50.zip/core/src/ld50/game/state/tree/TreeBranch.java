package ld50.game.state.tree;

import java.util.ArrayList;

import ld50.game.state.tree.Tree.BranchRun;

public class TreeBranch <T>{

	//fields
	private T object;
	private ArrayList<TreeBranch<T>> children;
	
	//creating a new branch
	public TreeBranch(T object) {
		this.object = object;
		children = new ArrayList<TreeBranch<T>>();
	}
	
	/*** Adds children to the current branch*/
	@SuppressWarnings("unchecked")
	public void addChildren(TreeBranch<T>... objects) {
		for(int i = 0; i < objects.length; i++) {
			children.add(objects[i]);
		}
	}

	/*** Adds children to the current branch*/
	public void addChildren(ArrayList<TreeBranch<T>> objects) {
		for(int i = 0; i < objects.size(); i++) {
			children.add(objects.get(i));
		}
	}

	/***Get child*/
	public TreeBranch<T> getChild(int index){
		return children.get(index);
	}

	/***Get children*/
	public ArrayList<TreeBranch<T>> getChildren(){
		return children;
	}
	
	/***Get first child*/
	public TreeBranch<T> getFirstChild(){
		return children.size() > 0 ? children.get(0) : null;
	}

	/*** Runs lambda expression for all subsequent branches */
	public void runBranch(BranchRun<T> func) {
		func.run(this);
		
		for (int i = 0; i < children.size(); i++) {
			children.get(i).runBranch(func);
		}
	}

	/*** Runs lambda expression for all subsequent branches */
	public void runBranchBackwards(BranchRun<T> func) {
		for (int i = 0; i < children.size(); i++) {
			children.get(i).runBranchBackwards(func);
		}
		
		func.run(this);
		
	}
	
	/*** Gets the object of the branch*/
	public T getObject() {return object;}
	
	/*** Gets amount of children*/
	public int getChildCount() {
		return children.size();
	}
	
}
