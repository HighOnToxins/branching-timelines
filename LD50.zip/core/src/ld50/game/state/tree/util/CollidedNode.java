package ld50.game.state.tree.util;

import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.line.Node;
import ld50.game.util.objects.Vector2D;

public class CollidedNode{
	
	//fields
	private TreeBranch<Line> branch;
	private int nodeIndex;

	//constructor
	public CollidedNode(TreeBranch<Line> branch, int nodeIndex) {
		this.branch = branch;
		this.nodeIndex = nodeIndex;
	}
	
	//get
	public TreeBranch<Line> getBranch() {return branch;}
	public int getNodeInndex() {return nodeIndex;}
	
	public Vector2D getNodePosition() {return branch.getObject().getNodePosition(nodeIndex);}
	public Vector2D getStartPosition() {return branch.getObject().getStartPosition();}
	public Node getNode() {return branch.getObject().getNode(nodeIndex);}
}
