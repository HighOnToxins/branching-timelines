package ld50.game.state.tree.util;

import ld50.game.state.tree.Tree;
import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.Tree.BranchRun;

public class TreeUtil <T>{

	//fields
	private Tree<T> tree;
	
	//constructor
	public TreeUtil(Tree<T> tree) {
		this.tree = tree;
	}

	public interface RunBranch<I>{
		void run(TreeBranch<I> parent);
	}
	
	/*** Adds a new branch at branch at index. If multiple children are found, branching branch is returned.*/
	public TreeBranch<T> getIndex(int i) {
		
		// Continues getting the next branch i times
		TreeBranch<T> currentBranch = tree.getHead();
		
		while(currentBranch.getChildCount() == 1 && i >= 0) {
			currentBranch = currentBranch.getFirstChild();
			i--;
		}
		
		return currentBranch;
	}
	
	/*** Updates the tree, growing each branch which does not have any children by one branch */
	public void runEndBranches(RunBranch<T> func) {
		runEndBranch(tree.getHead(), func);
	}
	
	/*** This function recursively runs each end branch.*/
	private void runEndBranch(TreeBranch<T> branch, RunBranch<T> func) {
		
		//runs function at end branch
		if(branch.getChildCount() == 0) {
			func.run(branch);
			return;
		}
		
		//tries at children to run instead
		for (int i = 0; i < branch.getChildCount(); i++) {
			runEndBranch(branch.getChild(i), func);
		}
	}

	/*** Interacts with each branch using the lambda expression. */
	public void runBranches(BranchRun<T> func) {
		tree.runBranches(func);
	}
	
	/*** Interacts with each branch using the lambda expression. */
	public void runBranchesBackwards(BranchRun<T> func) {
		tree.runBranchesBackwards(func);
	}
	
	/*** Gets the amount of branches in the tree*/
	public int branchCount() {
		return countBranch(tree.getHead());
	}

	/*** The branch counts itself and makes its children count their children.*/
	private int countBranch(TreeBranch<T> branch) {
		
		int childBranches = 0;
		
		//Looks through each child
		for (int i = 0; i < branch.getChildCount(); i++) {
			childBranches += countBranch(branch.getChild(i));
		}
		
		//counts each additional child other than the first
		return 1 + childBranches;
		
	}
	/*** Get the number of branchings */
	public int countBranching() {
		return countBranchings(tree.getHead());
	}
	
	private int countBranchings(TreeBranch<T> branch) {
		
		int childBranches = 0;
		
		//Looks through each child
		for (int i = 0; i < branch.getChildCount(); i++) {
			childBranches += countBranchings(branch.getChild(i));
		}
		
		//counts each additional child other than the first
		return Math.max(branch.getChildCount() - 1, 0) + childBranches;
		
	}
	
}
