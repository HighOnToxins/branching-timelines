package ld50.game.state.tree;

import ld50.game.state.tree.util.TreeUtil;

public class Tree <T>{

	/***Additional functions*/
	public TreeUtil<T> util;
	
	// Fields
	private TreeBranch<T> head;
	
	// Creating a new tree.
	public Tree(TreeBranch<T> object) {
		head = object;
		util = new TreeUtil<T>(this);
	}
	
	/*** Gets the head of the current tree */
	public TreeBranch<T> getHead(){return head;}

	// Creating interface for lambda expression
	public interface BranchRun<T>{
		void run(TreeBranch<T> treeBranch);
	}
	
	/*** Interacts with each branch using the lambda expression. */
	public void runBranches(BranchRun<T> func) {
		head.runBranch(func);
	}
	
	/*** Interacts with each branch using the lambda expression. */
	public void runBranchesBackwards(BranchRun<T> func) {
		head.runBranchBackwards(func);
	}
	
}
