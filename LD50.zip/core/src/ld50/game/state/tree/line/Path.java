package ld50.game.state.tree.line;

import ld50.game.util.objects.Vector2D;

public class Path extends Line {

	//fields
	private boolean travelingRight;
	
	public Path(Vector2D pos, float size, float speed, boolean travelingRight) {
		super(pos, size, speed, -1, -1);
		
		this.travelingRight = travelingRight;
		
	}

	//get
	public boolean getTravelingRight() {return travelingRight;}
	
	//set
	@Override public Vector2D getStartPosition() {return new Vector2D(startX, nodes.get(0).getPosition());}
	@Override public Vector2D getNodePosition(int index) {return new Vector2D(startX + index * (STEP_SIZE / 2) * (travelingRight ? 1 : -1), nodes.get(index).getPosition());}
	@Override public Vector2D getEndNodePosition() {return getNodePosition(nodes.size() - 1);}
}
