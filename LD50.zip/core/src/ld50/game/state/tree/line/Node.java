package ld50.game.state.tree.line;

public class Node {

	//fields
	private float position;
	private float speed;
	private int travelTime;
	private int spawnTime;
	
	//constructor
	public Node(float position, float speed, int travelTime, int spawnTime) {
		this.position = position;
		this.setSpeed(speed);
		this.travelTime = travelTime;
		this.spawnTime = spawnTime;
	}

	//get
	public float getSpeed() {return speed;}
	public float getPosition() {return position;}
	
	public int getTravelTime() {return travelTime;}
	public int getSpawnTime() {return spawnTime;}
	
	public boolean travel() {return travelTime == 0;}
	public boolean spawn() {return spawnTime == 0;}
	
	//set
	public void setSpeed(float speed) {this.speed = speed;}
	public void setTravelTime(int f) {travelTime = f;}
	public void setSpawnTime(int f) {spawnTime = f;}
	
}
