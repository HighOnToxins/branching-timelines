package ld50.game.state.tree.line;

import java.util.ArrayList;

import ld50.game.util.objects.Button;
import ld50.game.util.objects.Vector2D;

// part of the time line
public class Line {

	// - add fields like color and stuff later
	public static final int STEP_SIZE = 2, BUTTON_SIZE = 75;
	
	protected float startX, size;
	protected ArrayList<Node> nodes;
	
	private boolean dead, active, containsTraveler;
	
	//additional objects
	private Button headButton;
	
	//constructors
	public Line(Vector2D pos, float size, float speed, int travelTime, int spawnTime) {
		//setting variables
		nodes = new ArrayList<Node>();
		nodes.add(new Node(pos.getY(), speed, travelTime, spawnTime));
		init(pos.getX(), size, nodes, false);
	}

	//constructors
	public Line(float startX, float size, ArrayList<Node> nodes) {init(startX, size, nodes, false);}

	public Line(float startX, float size, ArrayList<Node> nodes, boolean buttonPressed) {init(startX, size, nodes, buttonPressed);}

	private void init(float startX, float size, ArrayList<Node> nodes, boolean buttonPressed) {
		//setting variables
		this.startX = startX;
		this.size = size;
		this.nodes = nodes;

		headButton = new Button(getEndNodePosition(), new Vector2D(BUTTON_SIZE), true, buttonPressed);

		dead = false;
		active = true;
	}

	// Set
	public ArrayList<Node> splitNodes(int index) {
		ArrayList<Node> endPart = new ArrayList<Node>();
		
		//loops through each end part of the node, adding it to the new list
		endPart.add(nodes.get(index));
		while(index + 1 < nodes.size()) {
			endPart.add(nodes.remove(index + 1));
		}
		
		return endPart;
	}

	// Set
	public void addNode(float position, float speed, int travelTime, int spawnTime) {nodes.add(new Node(position, speed, travelTime, spawnTime));}
	public void setEndSpeed(float speed) {nodes.get(nodes.size() - 1).setSpeed(speed);}

	public void kill() {dead = true; deactivate(); headButton.deactivate();}
	public void deactivate() {active = false; headButton.deactivate();}

	public void addTraveler() {containsTraveler = true;}
	public void removeTraveler() {containsTraveler = false;}
	
	// Get
	public Button getButton() {return headButton;}
	public Vector2D getStartPosition() {return new Vector2D(startX, nodes.get(0).getPosition());}
	public Vector2D getNodePosition(int index) {return new Vector2D(startX + index * STEP_SIZE, nodes.get(index).getPosition());}
	public Vector2D getEndNodePosition() {return getNodePosition(nodes.size() - 1);}
	
	public Node getNode(int index) {return nodes.get(index);}
	public Node getEndNode() {return nodes.get(nodes.size() - 1);}
	
	public int getNodeCount() {return nodes.size();}
	public float getSize() {return size;}
	
	public boolean isDead() {return dead;}
	public boolean isActive() {return active;}

	public boolean containsTraveler() {return containsTraveler;}

}
