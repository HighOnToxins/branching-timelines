package ld50.game.util;

import com.badlogic.gdx.graphics.Texture;

public class Resources {
	
	//Resources 
	//Images
//	public Texture texture;
//	public TextureRegion[] singleArray;
//	public TextureRegion[][] doubleArray;
	public Texture structure;
	
	//Sound Effects
//	public Sound sound;
	
	//Music
//	public Music music;

	//loading in all resources
	public void load() {		
		try {
			
			//LOAD IMAGES
//			texture = new Texture(Gdx.files.internal("images/[path].png"));
//			singleArray = loadTexReg("images/[path].png", 4);
//			doubleArray = loadTexReg("images/[path].png", 4, 3);
			structure = new Texture("textures/structureBackground.png");
			
//			//LOAD SOUND EFFECTS
//			sound = Gdx.audio.newSound(Gdx.files.internal("audio/[path].wav")); //sound.play([VOLUME]);
			
			//LOAD MUSIC
//			music = Gdx.audio.newMusic(Gdx.files.internal("audio/[path].mp3")); //music.play();
			
		}catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	//loading texture regions
	//single array
//	private TextureRegion[] loadTexReg(String path, int n) {
//		Texture tex = new Texture(path);
//		TextureRegion texReg[] = new TextureRegion[n];
//		for (int num = 0; num < texReg.length; num++) {
//			texReg[num] = new TextureRegion(tex, 
//					num     * (1f/n), 0, 
//					(num+1) * (1f/n), 1);
//		}
//		
//		return texReg;
//	}
//	
//	//double array
//	private TextureRegion[][] loadTexReg(String path, int w, int h) { 
//		Texture tex = new Texture(path);
//		TextureRegion texReg[][] = new TextureRegion[w][h];
//		for (int row = 0; row < texReg.length; row++) {
//			for (int col = 0; col < texReg[0].length; col++) {
//				texReg[row][col] = new TextureRegion(tex, 
//						row     * (1f/w), col     * (1f/h), 
//						(row+1) * (1f/w), (col+1) * (1f/h));
//			}
//		}
//		
//		return texReg;
//	}
	
}
