package ld50.game.util;

import com.badlogic.gdx.math.Rectangle;

import ld50.game.util.objects.GameObject;
import ld50.game.util.objects.Vector2D;

public class CollisionUtil {

	/***lineSegments collision*/
	public boolean lineSegments(Vector2D A1, Vector2D A2, Vector2D B1, Vector2D B2) {
		
		//Getting variables for getting (infinite) line intersection and then getting intersection
		float a1 = (A1.getY() - A2.getY()) / (A1.getX() - A2.getX());
		float b1 = A1.getY() - a1 * A1.getX();
		float a2 = (A1.getY() - A2.getY()) / (A1.getX() - A2.getX());
		float b2 = A1.getY() - a1 * A1.getX();
		
		Vector2D intersection = Util.lineIntersection(a1, b1, a2, b2);
		
		float l1 = Vector2D.sub(A1, intersection).getSquareLength();
		float l2 = Vector2D.sub(A2, intersection).getSquareLength();
		
		return Math.max(l1, l2) <= Vector2D.sub(A2, A1).getSquareLength();
		
	}
	
	/***Circle-point collision*/
	public boolean circlePoint(GameObject object, Vector2D point) {
		return Vector2D.sub(object.getPosition(), point).getSquareLength() <= object.getSize().scale(1/2f).getSquareLength();
	}

	/***Circle-point collision*/
	public boolean circlePoint(Vector2D pos, float radius, Vector2D point) {
		return Vector2D.sub(pos, point).getSquareLength() <= Math.pow(radius, 2);
	}
	
//	/***Box-point collision*/
//	public boolean boxPoint(Vector2D A, Vector2D B, Vector2D point) {
//		return new Rectangle(
//			A.getX(), 
//			A.getY(), 
//			B.getX() - A.getX(), 
//			B.getY() - A.getY()).contains(point.getX(), point.getY());
//	}
	
	/***Box-point collision*/
	public boolean boxPoint(GameObject object, Vector2D point) {
		return new Rectangle(
			object.getPosition().getX(), 
			object.getPosition().getY(), 
			object.getSize().getX(), 
			object.getSize().getY()).contains(point.getX(), point.getY());
	}
	
	/***Box-box collision*/
	public boolean boxBox(GameObject object, Vector2D point) {
		return new Rectangle(
			object.getPosition().getX(), 
			object.getPosition().getY(), 
			object.getSize().getX(), 
			object.getSize().getY()).overlaps(new Rectangle(
					object.getPosition().getX(), 
					object.getPosition().getY(), 
					object.getSize().getX(), 
					object.getSize().getY()));
	}
}
