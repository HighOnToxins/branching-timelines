package ld50.game.util.objects;

public class Vector2D {

	//fields
	private float x, y;
	
	//creating the vector
	public Vector2D() {x = y = 0;}
	public Vector2D(float f) {x = y = f;}
	
	public Vector2D(float x, float y) {
		this.x = x;
		this.y = y;
	}
	
	//getting Vector2D
	public float getX() {return x;} //getting x
	public float getY() {return y;} //getting y
	
	public float getLength() {return (float) Math.sqrt(x*x + y*y);} //getting length
	public float getSquareLength() {return (float) x*x + y*y;} //getting length
	
	//setting Vector2D
	public Vector2D setX(float f) {return new Vector2D(f, y);}
	public Vector2D setY(float f) {return new Vector2D(x, f);}

	public Vector2D setLength(float f) {return scale(f/getLength());} //setting length (Can not divde by zero)
	public Vector2D normalize() {return setLength(1);} //setting length to 1
	
	//Operators
	
		//dot product
	public float dot(Vector2D v) {
		return this.x*v.x + this.y*v.y;
	}
	
		//project
	public Vector2D proj(Vector2D v) {
		return this.scale(this.dot(v) / this.getSquareLength());
	}
	
		//Vector and Vector
	public static Vector2D sum(Vector2D... v) 	{return loopOp((a, b) -> a + b, v);}
	public static Vector2D sub(Vector2D... v) 	{return loopOp((a, b) -> a - b, v);}
	public static Vector2D prod(Vector2D... v)	{return loopOp((a, b) -> a * b, v);}
	
	private interface Operation{
		float run(float x1, float x2);
	}
	
	private static Vector2D loopOp(Operation func, Vector2D... v)	{
		if(v.length == 0) return null;
		
		float x = v[0].x, y = v[0].y;
		
		for(int i = 1; i < v.length; i++){
			x = func.run(x, v[i].x);
			y = func.run(y, v[i].y);
		}
		
		return new Vector2D(x, y);
	}
	
		//Vector and float
	public Vector2D add(float f) 		{return new Vector2D(x + f, y + f);} 
	public Vector2D sub(float f) 		{return new Vector2D(x - f, y - f);} 
	public Vector2D scale(float f) 		{return new Vector2D(x * f, y * f);} 

	//Absolute value of each
	public Vector2D setAbs()				{return new Vector2D(Math.abs(x), Math.abs(y));}
	
	//equals
	public boolean equals(Vector2D v) 	{return x == v.getX() && y == v.getY();}
	
	@Override
	public Vector2D clone()					{return new Vector2D(x, y);}
}
