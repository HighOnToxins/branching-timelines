package ld50.game.util.objects;

import ld50.game.util.Util;

public class Camera extends GameObject{
	//fields
	private float scale;
	
	//Constructor
	public Camera() {
		//setting position, size and velocity
		position = Util.window.size.scale(1/2f);
		size = Util.window.size.clone();
		
		scale = 1;
		
	}
	
	//getting variables
	public float getScale(){return scale;}
	
	//? to camera ?
	public Vector2D worldPosToScreenPos(Vector2D vec) {return Vector2D.sum(worldSizeToScreenSize(Vector2D.sum(Vector2D.sub(vec, position))), size.scale(1/2f));} 
	public Vector2D worldSizeToScreenSize(Vector2D vec){return vec.scale(1/scale);}
	
	public float worldSizeToScreenSize(float f){return f/scale;}
	
	//? to camera ? inverse
	public Vector2D screenPosToWorldPos(Vector2D vec) {return Vector2D.sum(screenSizeToWorldSize(Vector2D.sub(vec, size.scale(1/2f))), position);}
	public Vector2D screenSizeToWorldSize(Vector2D vec) {return vec.scale(scale);}
	
	//setting scale
	public void setScale(float f){scale = f;}
	public void addScale(float f){scale += f;}
	
}
