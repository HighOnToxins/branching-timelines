package ld50.game.util.objects;

public abstract class GameObject {
	//fields
	protected Vector2D position, size;
	
	//constructors
	public GameObject(Vector2D pos, Vector2D size) {
		//setting variables
		this.position = pos;
		this.size = size;
	}

	//clone
	public GameObject(GameObject obj) {
		this.position = obj.getPosition().clone();
		this.size = obj.getSize().clone();
	}
	
	//setting all zero
	public GameObject() {
		position = new Vector2D();
		size = new Vector2D();
	}

	//getting vectors
	public Vector2D getPosition() {return position;}
	public Vector2D getSize() {return size;}
	
	//setting vectors
	public void setPosition(Vector2D vec) {position = vec;}
	public void setSize(Vector2D vec) {size = vec;}
}
