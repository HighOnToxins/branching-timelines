package ld50.game.util.objects;

public class Button extends GameObject {
	
	//fields
	private boolean hover, pressed, circle, active;
	
	//constructor
	public Button(Vector2D pos, Vector2D size, boolean circle, boolean pressed) {
		super(pos, size);
		hover = false;
		this.pressed = pressed;
		this.circle = circle;
		active = true;
	}

	//get
	public boolean isHover() {return hover;}
	public boolean isPressed() {return pressed;}
	public boolean isCircle() {return circle;}
	public boolean isActive() {return active;}
	
	//set
	public void setHover(boolean b) {hover = b;}
	public void setPressed(boolean b) {pressed = b;}
	public void deactivate() {active = false;}
	
}
