package ld50.game.util;

import ld50.game.util.objects.Vector2D;

public class Util {
	
	public interface Operation {
		float run(float a, float b);
	}
	
	/*** Loops each element of array, doing the operation each time */
	public static float loopOp(Operation oper, float... array) {
		float total = array[0];
		
		for (int i = 1; i < array.length; i++) {
			total = oper.run(total, array[i]);
		}
		
		return total;
	}
	
	/*** sums up all inputs. */
	public static float sum(float... array) {
		return loopOp((total, next) -> total + next, array);
	}
	
	public static float avg(float... a) {
		return sum(a) / a.length;
	}
	
	public static float normalize(float a) {
		return a > 0 ? +1 : (a < 0 ? -1 : 0);
	}

	public static float normalizeRand(float a) {
		return a > 0 ? +1 : (a < 0 ? -1 : (Math.random() < .5 ? 1 : 0));
	}
	
	/*** Map the value x linearly */
	public static float map(float x, float start_min, float start_max, float end_min, float end_max) {
		return (x - start_min) * ((start_min - start_max) / (end_min - end_max)) + end_min;
	}

	/*** Calculating the point collision point of two infinite lines*/
	public static Vector2D lineIntersection(float a1, float b1, float a2, float b2) {
		float x = (b2 - b1) / (a1 - a2);
		return new Vector2D(x, a1 * x + b1);
	}
	
	// Additional functions
	public static DrawUtil draw = new DrawUtil();
	public static CollisionUtil collision = new CollisionUtil();
	public static WindowUtil window = new WindowUtil();
	public static Resources rec = new Resources();
}
