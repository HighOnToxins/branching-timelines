package ld50.game.util;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import ld50.game.util.objects.Camera;
import ld50.game.util.objects.GameObject;
import ld50.game.util.objects.Vector2D;

public class DrawUtil {
	public void translucentBox(ShapeRenderer shapes, Vector2D position, Vector2D size, Color color) {
		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);
		
		shapes.setColor(color);
		shapes.rect(position.getX(), position.getY(), size.getX(), size.getY());
		
		shapes.end();
		
		Gdx.gl.glDisable(GL20.GL_BLEND);
	}
	
	public void box(ShapeRenderer shapes, Vector2D position, Vector2D size, Color color) {
		shapes.begin(ShapeType.Filled);
		
		shapes.setColor(color);
		shapes.rect(position.getX(), position.getY(), size.getX(), size.getY());
		
		shapes.end();
	}
	

	//draw hit box
	public void drawBox(GameObject object, SpriteBatch batch, ShapeRenderer shapes, Color color) {
		//setting drawing to shapes
		batch.end();
		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);

		//drawing rectangle
		shapes.setColor(color);
		shapes.rect(object.getPosition().getX() - object.getSize().getX() / 2, object.getPosition().getY() - object.getSize().getY() / 2, object.getSize().getX(), object.getSize().getY());
		
		//setting drawing to batch
		shapes.end();
		Gdx.gl.glDisable(GL20.GL_BLEND);
		batch.begin();
	}
	
	//draw hit box based on camera
	public void drawBox(GameObject object, SpriteBatch batch, ShapeRenderer shapes, Camera cam, Color color) {
		
		//getting new object.position and object.getSize()
		Vector2D p = cam.worldPosToScreenPos(object.getPosition()),
			   s = cam.worldSizeToScreenSize(object.getSize());
		
		//setting drawing to shapes
		batch.end();
		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);
		
		//drawing rectangle
		shapes.setColor(color);
		shapes.rect(p.getX() - s.getX() / 2, p.getY() - s.getY() / 2, s.getX(), s.getY());
		
		//setting drawing to batch
		shapes.end();
		Gdx.gl.glDisable(GL20.GL_BLEND);
		batch.begin();
	}

	//draw image
	public void drawImage(Vector2D position, SpriteBatch batch, ShapeRenderer shapes, Texture texture, float scale) {
		batch.draw(texture, 
				position.getX(), 
				position.getY(),
				texture.getWidth() * scale,
				texture.getHeight() * scale);
	}
	
	//draw image
	public void drawImage(GameObject object, SpriteBatch batch, ShapeRenderer shapes, Texture texture, float scale) {
		batch.draw(texture, 
				object.getPosition().getX(), 
				object.getPosition().getY(),
				texture.getWidth() * scale,
				texture.getHeight() * scale);
	}

	//draw image based on Camera
	public void drawImage(Vector2D position, Vector2D size, SpriteBatch batch, ShapeRenderer shapes, Camera cam, Texture texture, float scale) {

		//getting new object.position and object.getSize()
		Vector2D p = cam.worldPosToScreenPos(position.scale(scale)),
			   s = cam.worldSizeToScreenSize(size.scale(scale));
		
		//drawing image
		batch.draw(texture, p.getX(), p.getY(), s.getX(), s.getY());
	}
	
	//draw image based on Camera
	public void drawImage(GameObject object, SpriteBatch batch, ShapeRenderer shapes, Camera cam, Texture texture) {

		//getting new object.position and object.getSize()
		Vector2D p = cam.worldPosToScreenPos(object.getPosition()),
			   s = cam.worldSizeToScreenSize(object.getSize());
		
		//drawing image
		batch.draw(texture, p.getX(), p.getY(), s.getX(), s.getY());
	}
	
}
