package ld50.game.util;

import com.badlogic.gdx.Gdx;

import ld50.game.util.objects.Vector2D;

public class WindowUtil {

	public final String title = "LD50";
	public final Vector2D size = new Vector2D(1280, 720);
	public final int pixelSize = 12;
	
	public float deltaTime(){return Math.min(.25f, Gdx.graphics.getDeltaTime());}
	
}
