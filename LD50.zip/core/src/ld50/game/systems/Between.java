package ld50.game.systems;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import ld50.game.util.Util;

public class Between extends GameSystem {
	//fields
	private GameSystem s0, s1;
	
	private float transparency, time;
	private boolean view0;
	
	//getters
	public GameSystem getNextState() {return s1;}
	
	//constructor
	public Between(GameSystemManager GSM, GameSystem s0, GameSystem s1) {
		super(GSM);
		
		//setting variables
		time = .25f;
		
		if(s0 != null) {
			transparency = 0f;
			view0 = true;
		}else {
			view0 = false;
			transparency = 1f;
		}
		
		//setting states
		this.s0 = s0;
		this.s1 = s1;
	}

	//update
	@Override
	public void update() {
		if(view0) { //disappear
			transparency += Util.window.deltaTime() * 2 / time;
			
			if(transparency > 1f) {
				transparency = 2 - transparency;
				view0 = false;
			}
		}else { //appear
			transparency -= Util.window.deltaTime() * 2 / time;
			
			if(transparency < 0f) {
				GSM.setSystem(-1);
			}
		}
	}

	//draw
	@Override
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {
		//drawing previous and next state
		if(view0) {
			if(s0 != null) {
				s0.draw(batch, shapes);
			}
		}else {
			if(s1 != null) {
				s1.draw(batch, shapes);
			}
		}
		
		//drawing transparent color
		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);
		
		shapes.setColor(new Color(0, 0, 0, Math.max(Math.min(transparency, 1f), 0f)));
		shapes.rect(0, 0, Util.window.size.getX(), Util.window.size.getY());
		
		shapes.end();
		
		Gdx.gl.glDisable(GL20.GL_BLEND);
		
	}

}
