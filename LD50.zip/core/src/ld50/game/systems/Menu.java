package ld50.game.systems;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import ld50.game.Main;
import ld50.game.util.Util;
import ld50.game.util.objects.Vector2D;

public class Menu extends GameSystem {
	//fields
	private float timer;
	private float resetPlay;
	private boolean show;
	
	private Play play;
	
	//constructor
	public Menu(GameSystemManager GSM, Play play) {
		super(GSM);

		this.play = play;
		
		//setting variables
		resetPlay = 5;
		timer = 0;
		show = false;
	}
	
	//update
	@Override
	public void update() {
		play.update();
		
		if(play.isDead()) {
			resetPlay -= Util.window.deltaTime();
			
			if(resetPlay <= 0) {
				resetPlay = 5;
				play = new Play(GSM, false);
			}
		}
		
		timer -= Util.window.deltaTime();
		if(timer <= 0) {
			if(show) timer = .5f;
			if(!show) timer = 1f;
			
			show = !show;
		}
	}
	
	//draw
	@Override
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {
		
		//setting drawing mode to shapes
		Util.draw.box(shapes, new Vector2D(), Util.window.size, new Color(.7f, .7f, .7f, 1f));
		
		play.draw(batch, shapes);
		
		Util.draw.translucentBox(shapes, new Vector2D(), Util.window.size, new Color(.5f, .5f, .5f, .5f));
		
		batch.begin();
		
		Main.font.getData().setScale(6.55f);
		Main.font.setColor(Color.WHITE);
		Main.font.draw(batch, "CONVERGING TIMELINES", Util.window.size.getX() / 100 + 6.55f, Util.window.size.getY() - Util.window.size.getY() / 4 + 50);
		Main.font.setColor(Color.BLACK);
		Main.font.draw(batch, "CONVERGING TIMELINES", Util.window.size.getX() / 100, Util.window.size.getY()- Util.window.size.getY() / 4 + 50);

		Main.font.getData().setScale(2f);
		Main.font.setColor(Color.BLACK);
		Main.font.draw(batch, "The year is 2023 and timetravel has been discovered...", Util.window.size.getX() / 100, Util.window.size.getY() / 2 - 75);
		Main.font.draw(batch, "Use WASD to control the camera and the mouse to drag the timelines,", Util.window.size.getX() / 100, Util.window.size.getY() / 2 - 125);
		Main.font.draw(batch, "keep at least one timeline alive,", Util.window.size.getX() / 100, Util.window.size.getY() / 2 - 175);
		Main.font.draw(batch, "and do your best delaying the coruption of the multiverse.", Util.window.size.getX() / 100, Util.window.size.getY() / 2 - 225);
		
		batch.end();
	}

	@Override 
	public boolean keyDown(int keycode) {
		
		GSM.changeSystem(GSM.NEW_GAME);
		
		return false;
	}
	
	@Override 
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		
		GSM.changeSystem(GSM.NEW_GAME);
		
		return false;
	}
	
}
