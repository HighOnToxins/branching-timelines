package ld50.game.systems;

import java.util.ArrayList;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import ld50.game.logic.BackgroundLogic;
import ld50.game.logic.ButtonLogic;
import ld50.game.logic.CamController;
import ld50.game.logic.tree.TreeLogic;
import ld50.game.renderer.BackgroundRender;
import ld50.game.renderer.ButtonRender;
import ld50.game.renderer.TreeRender;
import ld50.game.state.*;
import ld50.game.state.tree.Tree;
import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.line.Path;
import ld50.game.util.Util;
import ld50.game.util.objects.Button;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class Play extends GameSystem{
	
	//variables
	private boolean isDead;
	private boolean hasSetGameOver;
	
	//state
	private Tree<Line> tree;
	
	//logic
	private TreeLogic treeLogic;
	private BackgroundLogic backLogic;
	private ButtonLogic buttonLogic;
	private CamController cameraController;
	
	//render
	private TreeRender treeRender;
	private ButtonRender buttonRender;
	private BackgroundRender backRender;
	
	//Constructor
	public Play(GameSystemManager GSM, boolean isPlaying) {
		super(GSM);
		
		//variables
		hasSetGameOver = !isPlaying;
		
		//creating states
		Line start = new Line(new Vector2D(Util.window.size.getX() / 10, Util.window.size.getY() / 2), 20, 0, -1, 100); 
		tree = new Tree<Line>(new TreeBranch<Line>(start));
		ArrayList<Path> travelPaths = new ArrayList<Path>();

		Background backState = new Background();

		ArrayList<Button> buttons = new ArrayList<Button>();
		
		Camera cam = new Camera();

		//setting up logic
		treeLogic = new TreeLogic(tree, buttons, backState, travelPaths, cam);
		backLogic = new BackgroundLogic(backState, tree);
		buttonLogic = new ButtonLogic(buttons, cam);
		cameraController = new CamController(cam);
		
		//creating render objects
		treeRender = new TreeRender(tree, travelPaths, cam);
		buttonRender = new ButtonRender(buttons, cam);
		backRender = new BackgroundRender(backState, cam);
		
	}
	
	//get dead
	public boolean isDead() {return isDead;}
	
	//Updating play system
	@Override
	public void update(){
		treeLogic.update();
		backLogic.update();
		buttonLogic.update();
		cameraController.simulate();
		
		//check dead
		if(tree.getHead().getObject().isDead() && !isDead){
			isDead = true;
			if(!hasSetGameOver) {
				hasSetGameOver = true;
				GSM.setSystem(GSM.GAME_OVER);
			}
		}
	}

	//drawing play system
	@Override
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {
		
		backRender.draw(batch, shapes);
		
		treeRender.draw(batch, shapes);
		
		buttonRender.draw(batch, shapes);
		
	}

	//kyes
	@Override 
	public boolean keyDown(int keycode) {
		if(keycode == Keys.ESCAPE) GSM.setSystem(GSM.PAUSE);
		return cameraController.keyDown(keycode);
	}

	@Override public boolean keyUp(int keycode) {return cameraController.keyUp(keycode);}
	
	//touch
	@Override public boolean touchDown(int screenX, int screenY, int pointer, int button) {return buttonLogic.touchDown(screenX, screenY, pointer, button);}
	@Override public boolean touchUp(int screenX, int screenY, int pointer, int button) {return buttonLogic.touchUp(screenX, screenY, pointer, button);}
	@Override public boolean mouseMoved(int screenX, int screenY) {treeLogic.mouseMoved(screenX, screenY); return buttonLogic.mouseMoved(screenX, screenY);}
	@Override public boolean touchDragged(int screenX, int screenY, int pointer) {return treeLogic.touchDragged(screenX, screenY, pointer);}

	@Override public boolean scrolled(float amountX, float amountY) {return cameraController.scrolled(amountX, amountY);}

}
