package ld50.game.systems;

import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public abstract class GameSystem implements InputProcessor{
	//fields
	protected GameSystemManager GSM;
	
	public GameSystem(GameSystemManager GSM){
		this.GSM = GSM;
	}
	
	//update
	public abstract void update();

	//drawing
	public abstract void draw(SpriteBatch batch, ShapeRenderer shapes);

	//input listeners
	//keys
	@Override public boolean keyDown(int keycode) {return false;}
	@Override public boolean keyUp(int keycode) {return false;}
	@Override public boolean keyTyped(char character) {return false;}

	//touch
	@Override public boolean touchDown(int screenX, int screenY, int pointer, int button) {return false;}
	@Override public boolean touchUp(int screenX, int screenY, int pointer, int button) {return false;}
	@Override public boolean touchDragged(int screenX, int screenY, int pointer) {return false;}
	@Override public boolean mouseMoved(int screenX, int screenY) {return false;}

	@Override public boolean scrolled(float amountX, float amountY) {return false;}

}
