package ld50.game.systems;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class GameSystemManager {
	//systems
	public final int MENU = 0;
	public final int NEW_GAME = 1;
	public final int LOAD_GAME = 2;
	public final int PAUSE = 3;
	public final int GAME_OVER = 4;
	
	//important systems
	private Between inbetween;
	private GameSystem system;
	private Play savedPlay;
	
	//Constructor making STACK
	public GameSystemManager(){
		system = null;
		
		//setting system
		changeSystem(MENU);
	}

	public GameSystem getState(int s) {
		switch(s){
		
		case MENU: 
			savedPlay = new Play(this, false); 
			return new Menu(this, savedPlay); 

		case NEW_GAME: 
			savedPlay = new Play(this, true); 
			return savedPlay;

		case LOAD_GAME: 
			return savedPlay;
		
		case PAUSE: 
			return new Pause(this, savedPlay); 

		case GAME_OVER: 
			return new GameOver(this, savedPlay); 
		
		default: 
			return null;
		
		}
	}
	
	//Changing system
	public void changeSystem(int s){
		//setting between
		inbetween = new Between(this, system, getState(s));
		system = inbetween;
		
		//setting input listeners to new system
		Gdx.input.setInputProcessor(system);
	}
	
	public void setSystem(int s) {
		//setting new system
		if(inbetween != null) {
			system = inbetween.getNextState();
			inbetween = null;
		}else {
			system = getState(s);
		}
		
		//setting input listeners to new system
		Gdx.input.setInputProcessor(system);
	}
	
	//updating systems
	public void update(){system.update();}
	
	//drawing systems
	public void draw(SpriteBatch batch, ShapeRenderer shapes){system.draw(batch, shapes);}
}
