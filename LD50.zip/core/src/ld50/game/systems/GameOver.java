package ld50.game.systems;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import ld50.game.Main;
import ld50.game.util.Util;

public class GameOver extends GameSystem {
	//fields
	private float controlTime;
	private Play play;
	
	//constructor
	public GameOver(GameSystemManager GSM, Play play) {
		super(GSM);
		
		//setting variables
		controlTime = 1f;
		
		//setting
		this.play = play;
	}
	
	//update
	@Override
	public void update() {
		play.update();
		
		controlTime -= Util.window.deltaTime();
	}
	
	//draw
	@Override
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {
		
		//drawing
		play.draw(batch, shapes);
		
		//drawing game over
		if(controlTime <= 0) {
			batch.begin();
			
			Main.font.getData().setScale(10.4f);
			Main.font.setColor(Color.WHITE);
			Main.font.draw(batch, "G A M E   O V E R", Util.window.size.getX() / 100 + 10.4f, Util.window.size.getY() / 2 + 70);
			Main.font.setColor(Color.BLACK);
			Main.font.draw(batch, "G A M E   O V E R", Util.window.size.getX() / 100, Util.window.size.getY() / 2 + 70);
			
			batch.end();
		}
	}


	public boolean keyDown(int keycode) {
		
		if(controlTime <= 0) {
			if(keycode == Keys.ESCAPE) {
				GSM.changeSystem(GSM.MENU);
			}else {
				GSM.changeSystem(GSM.NEW_GAME);
			}
		}
		
		return false;
	}

	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		
		GSM.setSystem(GSM.NEW_GAME);
		
		return false;
	}
	
}
