package ld50.game.systems;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import ld50.game.Main;
import ld50.game.util.Util;
import ld50.game.util.objects.Vector2D;

public class Pause extends GameSystem {
	//fields
	
	//states
	private Play play;
	
	//constructor
	public Pause(GameSystemManager GSM, Play play) {
		super(GSM);
		
		//setting variables
		
		//setting
		this.play = play;
	}
	
	//update
	@Override
	public void update() {
		
	}
	
	//draw
	@Override
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {
		
		//draw
		play.draw(batch, shapes);
		
		//add gray
		Util.draw.translucentBox(shapes, new Vector2D(), Util.window.size, new Color(0, 0, 0, .3f));
		
		//text
		batch.begin();
		
		Main.font.getData().setScale(12);
		Main.font.setColor(Color.WHITE);
		Main.font.draw(batch, "- P A U S E D -", Util.window.size.getX() / 100 + 12, Util.window.size.getY() / 2 + 12*9);
		Main.font.setColor(Color.BLACK);
		Main.font.draw(batch, "- P A U S E D -", Util.window.size.getX() / 100, Util.window.size.getY() / 2 + 12*9);
		
		batch.end();
	}

	public boolean keyDown(int keycode) {
		
		if(keycode == Input.Keys.ESCAPE) GSM.changeSystem(GSM.MENU);
		else GSM.setSystem(GSM.LOAD_GAME);
		
		return false;
	}

	@Override 
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		
		GSM.setSystem(GSM.LOAD_GAME);
		
		return false;
	}
	
	
	
}
