package ld50.game.logic;

import ld50.game.state.Background;
import ld50.game.state.tree.Tree;
import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.line.Line;
import ld50.game.util.Util;

public class BackgroundLogic {

	//fields
	private Background backState;
	private Tree<Line> tree;
	
	//constructor
	public BackgroundLogic(Background backState, Tree<Line> tree) {
		this.backState = backState;
		this.tree = tree;
	}
	
	public void update() {
		setScoreToFurthestTime();
		updateInstability();
	}
	
	public void setScoreToFurthestTime() {
		backState.setFurthestTime(furthestTime(tree.getHead())); 
	}
	
	private int furthestTime(TreeBranch<Line> branch) {
		
		int furthestTime = 0;
		
		for (int i = 0; i < branch.getChildCount(); i++) {
			int t = furthestTime(branch.getChild(i));
			if(t > furthestTime) {
				furthestTime = t;
			}
		}
		
		return furthestTime + branch.getObject().getNodeCount() - 1;
	}
	
	/*** Updates the instability. This method should be called each frame.*/
	public void updateInstability() {
		backState.addInstability(tree.util.branchCount() * Util.window.deltaTime() * 0.01f);
	}
	
}
