package ld50.game.logic;

import com.badlogic.gdx.Input.Keys;

import ld50.game.util.Util;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class CamController {
	
	//constants
	private static final float ACCELERATION_CONST = 8000;
	private static final float FRICTION = .7f;
	
	//fields
	private Camera cam;
	
	private Vector2D velocity;
	private Vector2D acceleration;
	
	private boolean up, down, left, right;
	
	//constructor
	public CamController(Camera cam) {
		this.cam = cam;
		velocity = new Vector2D();
		acceleration = new Vector2D();
	}

	//update
	public void simulate() {
		
		//get input direction
		Vector2D input = new Vector2D();
		if(up) 		input = Vector2D.sum(input, new Vector2D(0, +1));
		if(down) 	input = Vector2D.sum(input, new Vector2D(0, -1));
		if(left) 	input = Vector2D.sum(input, new Vector2D(-1, 0));
		if(right) 	input = Vector2D.sum(input, new Vector2D(+1, 0));
		if(input.getX() != 0 || input.getY() != 0) input = input.normalize();
		
		acceleration = input.scale(ACCELERATION_CONST);
		velocity = Vector2D.sum(velocity.scale(FRICTION), acceleration.scale(Util.window.deltaTime()));
		cam.setPosition(Vector2D.sum(cam.getPosition(), velocity.scale(Util.window.deltaTime())));
	}
	

	//player input
	public boolean keyDown(int keycode) {
		
		if(keycode == Keys.W || keycode == Keys.UP) up = true;
		if(keycode == Keys.S || keycode == Keys.DOWN) down = true;
		if(keycode == Keys.A || keycode == Keys.LEFT) left = true;
		if(keycode == Keys.D || keycode == Keys.RIGHT) right = true;
		
		return false;
	}
	
	public boolean keyUp(int keycode) {
		
		if(keycode == Keys.W || keycode == Keys.UP) up = false;
		if(keycode == Keys.S || keycode == Keys.DOWN) down = false;
		if(keycode == Keys.A || keycode == Keys.LEFT) left = false;
		if(keycode == Keys.D || keycode == Keys.RIGHT) right = false;
		
		return false;
	}

	public boolean scrolled(float amountX, float amountY) {
		cam.setScale(cam.getScale() * (amountY * 0.1f + 1f));
		return false;
	}

}
