package ld50.game.logic;

import java.util.ArrayList;

import ld50.game.Main;
import ld50.game.util.Util;
import ld50.game.util.objects.Button;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class ButtonLogic {
	
	//fields
	private ArrayList<Button> buttons;
	private Vector2D mousePosition;
	private boolean prevPressing, pressing;
	private Camera cam;
	
	//Constructor
	public ButtonLogic(ArrayList<Button> buttons, Camera cam) {
		this.buttons = buttons;
		mousePosition = new Vector2D();
		this.cam = cam;
	}
	
	//update
	public void update() {
		for (int i = 0; i < buttons.size(); i++) {
			if(!buttons.get(i).isActive()) continue;
			
			buttons.get(i).setHover(
					buttons.get(i).isCircle() ? 
							Util.collision.circlePoint(buttons.get(i), mousePosition) : 
							Util.collision.boxPoint(buttons.get(i), Vector2D.sub(mousePosition, buttons.get(i).getSize().scale(1/2f))));
			
			if(prevPressing != pressing && buttons.get(i).isHover()) buttons.get(i).setPressed(true);
			else if(!pressing) buttons.get(i).setPressed(false);
		}
		
		prevPressing = pressing;
	}
	
	//touch
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		pressing = true;
		return false;
	}
	
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		pressing = false;
		return false;
	}
	
	public boolean mouseMoved(int screenX, int screenY) {
		mousePosition = cam.screenPosToWorldPos(Main.getMouseCords(new Vector2D(screenX, screenY)));
		return false;
	}
	
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		mousePosition = cam.screenPosToWorldPos(Main.getMouseCords(new Vector2D(screenX, screenY)));
		return false;
	}

}
