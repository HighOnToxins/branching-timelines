package ld50.game.logic.tree;

import java.util.ArrayList;

import ld50.game.state.tree.Tree;
import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.line.Node;
import ld50.game.state.tree.line.Path;
import ld50.game.state.tree.util.CollidedNode;
import ld50.game.util.Util;
import ld50.game.util.objects.Vector2D;

public class TreeTraveler {

	//constants
	private static int SPAWN_MIN_TIME = 150;
	private static int SPAWN_MAX_TIME = 5000;
	
	private static int TRAVEL_MIN_TIME = 100;
	private static int TRAVEL_MAX_TIME = 500;
	
	private static final float TRAVELER_SIZE = 10f;
	private static final float TRAVEL_MIN_MOMENT = .5f;
	private static final float TRAVEL_MAX_MOMENT = 5f;
	
	//logic
	private TreeLogicUtil util;
	private TreeCollision collision;
	
	//state
	private Tree<Line> tree;
	private ArrayList<Path> travelPaths;
	
	//constructor
	public TreeTraveler(Tree<Line> tree, ArrayList<Path> travelPaths, TreeLogicUtil treeLogic, TreeCollision collision) {
		//logic
		this.util = treeLogic;
		this.collision = collision;
		
		//state
		this.tree = tree;
		this.travelPaths = travelPaths;
	}
	
	/***This function checks for new travelers. Should be called right after the grow(); function. */
	public void update() {
		beginTravel();
		travel();
		endTravel();
		
		spawn();
	}

	//start travel through time
	private void beginTravel() {
		tree.util.runEndBranches((branch) -> {
			if(		branch.getObject().isDead() || 
					!branch.getObject().isActive() || 
					!branch.getObject().containsTraveler() || 
					!branch.getObject().getEndNode().travel()) return;
				
			//splitting branch
			Line line = branch.getObject();
			util.splitLine(branch, line.getNodeCount() - 2);
			
			//adding time-traveler to end part
			branch.getChild(branch.getChildCount() - 1).getObject().removeTraveler();
			
			branch.getChild(branch.getChildCount() - 1).getObject().getEndNode().setSpawnTime((int)Util.map((float)Math.random(), 0, 1, SPAWN_MIN_TIME, SPAWN_MAX_TIME));
			
			//adding new travel path (since time-traveler is traveling through time)
			float speed = (float)Math.random()*(TRAVEL_MAX_MOMENT - TRAVEL_MIN_MOMENT) + TRAVEL_MIN_MOMENT;
			travelPaths.add(new Path(
					Vector2D.sum(line.getEndNodePosition(), new Vector2D(0, Util.normalize(speed) * branch.getObject().getSize())), 
					TRAVELER_SIZE, 
					speed, 
					Math.random() < .5)); 
				
		});
	}
	
	//traveling through time
	private void travel() {
		//looping active paths
		for (int i = 0; i < travelPaths.size(); i++) {
			if(!travelPaths.get(i).isActive()) continue;

			//Adding 
			Node endNode = travelPaths.get(i).getEndNode();
			travelPaths.get(i).addNode(
					endNode.getPosition() + endNode.getSpeed() / Line.STEP_SIZE, 
					endNode.getSpeed() + util.getAcceleration(endNode, false),
					endNode.getTravelTime() - 1,
					endNode.getSpawnTime() - 1);
			
		}
	}
	
	
	//traveling through time
	private void endTravel() {
		//looping active paths
		for (int i = 0; i < travelPaths.size(); i++) {
			if(!travelPaths.get(i).isActive()) continue;
			
			//checking for collision
			CollidedNode colNode = collision.getCollision(
					travelPaths.get(i).getEndNodePosition(), 
					travelPaths.get(i).getEndNode().getSpeed(),
					travelPaths.get(i).getSize() / 2);

			if(colNode != null) {
				travelPaths.get(i).deactivate();
				
				if(!colNode.getBranch().getObject().isDead()) {
					
					TreeBranch<Line> branch = util.addBranch(colNode.getBranch(), colNode.getNodeInndex());
					if(branch != null) {
						branch.getObject().addTraveler();
						branch.getObject().getEndNode().setTravelTime((int)Util.map((float)Math.random(), 0, 1, TRAVEL_MIN_TIME, TRAVEL_MAX_TIME));
					}
					
				}else {
					travelPaths.get(i).kill();
				}
			}
			
		}

	}
	
	//spawning time-travelers
	private void spawn() {
		tree.util.runEndBranches((branch) -> {
			if(		branch.getObject().isDead() || 
					!branch.getObject().isActive() || 
					branch.getObject().containsTraveler() ||
					!branch.getObject().getEndNode().spawn()) return;
			
			//splitting branch
			Line line = branch.getObject();
			util.splitLine(branch, line.getNodeCount() - 2); 

			//adding time-traveler to end part
			if(branch.getChildCount() >= 1) {
				branch.getChild(branch.getChildCount() - 1).getObject().getEndNode().setTravelTime((int)Util.map((float)Math.random(), 0, 1, TRAVEL_MIN_TIME, TRAVEL_MAX_TIME));
				branch.getChild(branch.getChildCount() - 1).getObject().addTraveler();
			}
			
		});
	}
	
	
}
