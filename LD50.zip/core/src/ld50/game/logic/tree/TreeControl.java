package ld50.game.logic.tree;

import ld50.game.Main;
import ld50.game.state.tree.Tree;
import ld50.game.state.tree.line.Line;
import ld50.game.util.Util;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class TreeControl {

	//fields
	private Tree<Line> tree;
	private Vector2D mousePosition;
	private Camera cam;
	
	//Constructor
	public TreeControl(Tree<Line> tree, Camera cam){
		this.tree = tree;
		mousePosition = new Vector2D();
		this.cam = cam;
	}
	
	//update controller
	public void update() {
		tree.util.runEndBranches((branch) -> {
			if(branch.getObject().getButton().isPressed()) {
				
				//getting distance vector between branch end position and mousePosition
				float dirY = mousePosition.getY() - branch.getObject().getEndNodePosition().getY();
				branch.getObject().getEndNode().setSpeed(Math.min(dirY * Util.window.deltaTime() * 10, 10));
				
			}
		});
	}
	
	public boolean mouseMoved(int screenX, int screenY) {
		mousePosition = cam.screenPosToWorldPos(Main.getMouseCords(new Vector2D(screenX, screenY)));
		return false;
	}
	
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		mousePosition = cam.screenPosToWorldPos(Main.getMouseCords(new Vector2D(screenX, screenY)));
		return false;
	}
}

