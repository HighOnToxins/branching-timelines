package ld50.game.logic.tree;

import java.util.ArrayList;

import ld50.game.state.Background;
import ld50.game.state.tree.Tree;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.line.Path;
import ld50.game.util.Util;
import ld50.game.util.objects.Button;
import ld50.game.util.objects.Camera;

public class TreeLogic {

	//fields
	private TreeLogicUtil util;
	private TreeControl controller;
	private TreeCollision collision;
	private TreeTraveler travelers; 
	
	private float tickDelay;
	private float tickTime;

	//constructor
	public TreeLogic(Tree<Line> tree, ArrayList<Button> buttons, Background backState, ArrayList<Path> travelPaths, Camera cam) {
		
		//Setting objects
		util = new TreeLogicUtil(tree, buttons, backState);
		controller = new TreeControl(tree, cam);
		collision = new TreeCollision(tree);
		travelers = new TreeTraveler(tree, travelPaths, util, collision);
		
		//time
		tickDelay = 1/30f;
		tickTime = tickDelay;
	}
	
	//update function
	public void update() {

		//running ticks 50 pr sec
		tickTime -= Util.window.deltaTime();
		
		while(tickTime <= 0) {
			tickTime += tickDelay;
			tick();
		}
		
	}
	
	//running ticks
	public void tick() {

		//collisions
		collision.update();
		
		//update death
		util.updateDeath();
		
		//update controller
		controller.update();
		
		//growing tree
		util.grow();
		
		//update travelers
		travelers.update();
		
		//set position of buttons to head of branches
		util.updateBranchButons();

		util.test();
	 
	}

	public boolean mouseMoved(int screenX, int screenY) {return controller.mouseMoved(screenX, screenY);}
	public boolean touchDragged(int screenX, int screenY, int pointer) {return controller.touchDragged(screenX, screenY, pointer);}
}
