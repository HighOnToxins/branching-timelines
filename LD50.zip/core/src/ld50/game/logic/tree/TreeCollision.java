package ld50.game.logic.tree;

import java.util.ArrayList;

import ld50.game.state.tree.Tree;
import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.util.CollidedNode;
import ld50.game.util.Util;
import ld50.game.util.objects.Vector2D;

public class TreeCollision {

	//fields 
	private Tree<Line> tree;
	
	//constructor
	public TreeCollision(Tree<Line> tree) {
		this.tree = tree;
	}
	
	//update
	public void update() {
		
		tree.util.runEndBranches((branch) -> {

			//checking possible candidates for intersection
			Line line = branch.getObject();
			Vector2D p = line.getEndNodePosition();
			
			CollidedNode collision = getCollision(p, line.getEndNode().getSpeed(), line.getSize()/2);

			//collides
			if(collision != null) {
				line.kill();
				collision.getBranch().getObject().kill();
			}
			
		});
		
	}
	
	public CollidedNode getCollision(Vector2D p, float speed, float radius) {
		
		ArrayList<CollidedNode> collisions = getNodesByX(tree.getHead(), p);
		
		for (int j = 0; j < collisions.size(); j++) {
//
//			Line colidee = collisions.get(j).getBranch().getObject();
//
//			if(		Util.normalize(speed) == Util.normalize(collisions.get(j).getNode().getPosition() - p.getY()) &&
//					Util.collision.circlePoint(p, colidee.getSize()/2 + radius, collisions.get(j).getNodePosition())) {
//				return collisions.get(j);
//			}
			
			float pos = collisions.get(j).getNode().getPosition();
			
			float preDir = Util.normalize(pos - (p.getY() + speed));
			float postDir = Util.normalize(pos - p.getY());
			
			if(pos != p.getY() && Util.normalize(speed) == Util.normalize(pos - p.getY()) && preDir != postDir) {
				return collisions.get(j);
			}
		}
		
		return null;
	}

	/*** Recursively runs, returning all nodes on the x-cord given as input.*/
	private ArrayList<CollidedNode> getNodesByX(TreeBranch<Line> branch, Vector2D p) {
		ArrayList<CollidedNode> out = new ArrayList<CollidedNode>();
		
		//run for children
		for (int i = 0; i < branch.getChildCount(); i++) {
			out.addAll(getNodesByX(branch.getChild(i), p));
		}
		
		//add (calculates node index)
		Line line = branch.getObject();
		int nodeIndex = (int)((float)(p.getX() - line.getStartPosition().getX()) / Line.STEP_SIZE);
		if(nodeIndex < line.getNodeCount() && nodeIndex >= 0 && line.getNode(nodeIndex).getPosition() != p.getY()) {
			out.add(new CollidedNode(branch, nodeIndex));
		}
		
		return out;
		
	}
	
}
