package ld50.game.logic.tree;

import java.util.ArrayList;

import ld50.game.state.Background;
import ld50.game.state.tree.Tree;
import ld50.game.state.tree.Tree.BranchRun;
import ld50.game.state.tree.TreeBranch;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.line.Node;
import ld50.game.util.Util;
import ld50.game.util.objects.Button;

public class TreeLogicUtil {

	//constants
	private static final float DECAY = .99f, 
							   MIN_BRANCH_ACC = 5, 
							   MAX_BRANCH_ACC = 10,
							   GRAVITY = .001f;
	
	//fields
	private Tree<Line>tree;
	private ArrayList<Button> buttons;
	private Background backState;

	//constructor
	public TreeLogicUtil(Tree<Line> tree, ArrayList<Button> buttons, Background backState) {
		
		//Setting objects
		this.tree = tree;
		this.buttons = buttons;
		this.backState = backState;
		
		//adding first branch button to buttons
		buttons.add(tree.getHead().getObject().getButton());
	}
	
	/*** Grows the tree*/
	public void grow() {
		tree.util.runEndBranches((branch) -> {
			if(!branch.getObject().isDead() && branch.getObject().isActive()) { //a dead branch can not grow
				Node lastNode = branch.getObject().getEndNode();
				branch.getObject().addNode(
						lastNode.getPosition() + (float)(Util.normalize(lastNode.getSpeed()) * Math.abs(lastNode.getSpeed())) / Line.STEP_SIZE, 
						lastNode.getSpeed() * DECAY + getAcceleration(lastNode, false) / Line.STEP_SIZE,
						lastNode.getTravelTime() - 1,
						lastNode.getSpawnTime() - 1);
			}
		});
	}

	/*** Adds a branch*/
	@SuppressWarnings("unchecked")
	public TreeBranch<Line> addBranch(TreeBranch<Line> branch, int index) {
		splitLine(branch, index);
		Line line = branch.getObject();
		Node node = branch.getObject().getEndNode();

		line.deactivate();
		
		Line newLine = new Line(
				line.getEndNodePosition(), 
				Math.max(line.getSize() * .8f, 5), 
				node.getSpeed() + getAcceleration(node, true),
				line.getEndNode().getTravelTime() - 1,
				line.getEndNode().getSpawnTime() - 1);
		buttons.add(newLine.getButton());
		
		TreeBranch<Line> newBranch = new TreeBranch<Line>(newLine);
		branch.addChildren(newBranch);
		
		return newBranch;
	}

	/*** Returns true if the split was successful.*/
	@SuppressWarnings("unchecked")
	public void splitLine(TreeBranch<Line> branch, int index) { 
		Line line = branch.getObject();
		
		//splitting the line into two (line and endPart)
		Line endPart = new Line(
				line.getNodePosition(index).getX(), 
				line.getSize(),
				line.splitNodes(index),
				line.getButton().isPressed());
		
		//adding end part as a child to line
		if(!line.isActive()) endPart.deactivate();
		if(line.isDead()) endPart.kill();
		if(line.containsTraveler()) endPart.addTraveler();
		line.deactivate();

		buttons.add(endPart.getButton());
		
		//fixing child order
		TreeBranch<Line> newBranch  = new TreeBranch<Line>(endPart);
		newBranch.addChildren(branch.getChildren());
		branch.getChildren().clear();
		branch.addChildren(newBranch);
	}
	
	/*** Returns a new acceleration given the type */
	public float getAcceleration(Node lastNode, boolean branching) {
		
		float acceleration = 0;

		//add to acceleration based on stability
		acceleration = (float) ((Math.random()*2-1)*Math.log(backState.getInstability() + 1));
		
		//add gravity to middle
		acceleration += (Util.window.size.getY() / 2 - lastNode.getPosition()) * GRAVITY;
		
		//add to acceleration based on type
		if(branching) acceleration += (Math.random()*(MAX_BRANCH_ACC - MIN_BRANCH_ACC) + MIN_BRANCH_ACC) * (Math.random() < .5 ? -1 : 1);
		
		return acceleration;
		
	}

	/*** Updates the buttons which are heads of*/
	public void updateBranchButons() {
		tree.util.runEndBranches((branch) -> {
			branch.getObject().getButton().setPosition(branch.getObject().getEndNodePosition());
		});
	}

	/*** Update death such that a dead parent kill the child, and if all children are dead parent also dies*/
	public void updateDeath() {
		
		BranchRun<Line> func = (branch) -> {

			//if parent is dead kill children
			if(branch.getObject().isDead()) {
				for (int i = 0; i < branch.getChildCount(); i++) {
					branch.getChild(i).getObject().kill();
				}
				return;
			}

			//if all children are dead kill parent
			if(branch.getChildCount() == 0) return;
			
			boolean isDead = true;
			for (int i = 0; i < branch.getChildCount() && isDead; i++) {
				if(!branch.getChild(i).getObject().isDead()) {
					isDead = false;
				}
			}
			if(isDead) {
				branch.getObject().kill();
			}
		};
		
		tree.util.runBranches(func);
		tree.util.runBranchesBackwards(func);
	}
	
	public void test() {
//		System.out.println(tree.util.countBranching() + "\t" + tree.util.branchCount());
	}
	
}
