package ld50.game.renderer;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import ld50.game.state.tree.Tree;
import ld50.game.state.tree.line.Line;
import ld50.game.state.tree.line.Path;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class TreeRender {

	//fields
	private Tree<Line> tree;
	private ArrayList<Path> travelPaths;
	private Camera cam;
	
	//constructor
	public TreeRender(Tree<Line> tree, ArrayList<Path> travelPaths, Camera cam) {
		
		this.tree = tree;
		this.travelPaths = travelPaths;
		this.cam = cam;
		
	}
	
	//draw method
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {

		shapes.begin(ShapeType.Filled);
		
		//draw circle at start
		//drawing tree
		tree.runBranchesBackwards((branch) -> {

			//drawing a line between the current node and the current child
			Line line = branch.getObject();

			for (int j = 0; j < line.getNodeCount() - 1; j++) {

				if(line.isDead()) {
					//Dead GRAY
					shapes.setColor(new Color(.5f, .5f, .5f, 1f));
				}else if(j >= branch.getObject().getNodeCount() - 5 && branch.getChildCount() == 0){
					//End WHITE
					shapes.setColor(new Color(1f, 1f, 1f, 1f));
				}else if(branch.getObject().containsTraveler()){
					//Traveler RED
					shapes.setColor(new Color(.8f, 0, 0, 1f));
				}else {
					//Default BLUE
					shapes.setColor(new Color(0f, 0f, .8f, 1f));
				}
				
				Vector2D dir = Vector2D.sub(line.getNodePosition(j + 1), line.getNodePosition(j));
				Vector2D current = cam.worldPosToScreenPos(Vector2D.sub(line.getNodePosition(j), dir.setLength(2)));
				Vector2D next = cam.worldPosToScreenPos(Vector2D.sum(line.getNodePosition(j + 1), dir.setLength(2)));

				shapes.rectLine(
						current.getX(), 
						current.getY(), 
						next.getX(), 
						next.getY(),
						cam.worldSizeToScreenSize(line.getSize()));
				
			}
			
			//draw X if branch is dead
			if(branch.getObject().isDead() && branch.getChildCount() == 0) {

				Vector2D mid = cam.worldPosToScreenPos(branch.getObject().getEndNodePosition());
				float size = cam.worldSizeToScreenSize(line.getSize());
				shapes.setColor(new Color(0f, 0, .8f, 1f));
				shapes.rectLine(
						mid.getX() - size, 
						mid.getY() - size, 
						mid.getX() + size, 
						mid.getY() + size,
						cam.worldSizeToScreenSize(line.getSize() / 2));
				shapes.rectLine(
						mid.getX() - size, 
						mid.getY() + size, 
						mid.getX() + size, 
						mid.getY() - size,
						cam.worldSizeToScreenSize(line.getSize() / 2));
				
			}
			
		});

		Vector2D startPos = cam.worldPosToScreenPos(tree.getHead().getObject().getStartPosition());
		shapes.setColor(new Color(0f, 0f, .8f, 1f));
		shapes.circle(startPos.getX(), startPos.getY(), cam.worldSizeToScreenSize(30));
		
		//setting drawing mode to batch
		shapes.end();

		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);
		
		//drawing traveler paths
		shapes.setColor(new Color(1f, 0, 0, .5f));
		
		for (int i = 0; i < travelPaths.size(); i++) {
			for (int j = 0; j < travelPaths.get(i).getNodeCount() - 1; j += (j % 20 == 0 ? 11 : 1)) {

				Vector2D current = cam.worldPosToScreenPos(travelPaths.get(i).getNodePosition(j));
				Vector2D next = cam.worldPosToScreenPos(travelPaths.get(i).getNodePosition(j + 1));

				//Traveler RED
				shapes.rectLine(
						current.getX(), 
						current.getY(), 
						next.getX(), 
						next.getY(),
						cam.worldSizeToScreenSize(travelPaths.get(i).getSize()));
			}
			
			if(travelPaths.get(i).isDead()) {

				Vector2D mid = cam.worldPosToScreenPos(travelPaths.get(i).getEndNodePosition());
				float size = cam.worldSizeToScreenSize(travelPaths.get(i).getSize());
				shapes.setColor(new Color(.8f, 0, 0f, .5f));
				shapes.rectLine(
						mid.getX() - size, 
						mid.getY() - size, 
						mid.getX() + size, 
						mid.getY() + size,
						cam.worldSizeToScreenSize(travelPaths.get(i).getSize() / 2));
				shapes.rectLine(
						mid.getX() - size, 
						mid.getY() + size, 
						mid.getX() + size, 
						mid.getY() - size,
						cam.worldSizeToScreenSize(travelPaths.get(i).getSize() / 2));
			}
		}

		shapes.end();
		Gdx.gl.glDisable(GL20.GL_BLEND);
	}
	
}
