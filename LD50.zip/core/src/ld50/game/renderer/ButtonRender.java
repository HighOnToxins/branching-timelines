package ld50.game.renderer;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import ld50.game.util.objects.Button;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class ButtonRender {

	//state
	private ArrayList<Button> buttons;
	private Camera cam;
	
	//constructor
	public ButtonRender(ArrayList<Button> buttons, Camera cam) {
		this.buttons = buttons;
		this.cam = cam;
	}
	
	//draw method
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {

		//drawing transparent color
		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);
		
		for (int i = 0; i < buttons.size(); i++) {
			if(buttons.get(i).isActive()) {

				if(!buttons.get(i).isHover() && !buttons.get(i).isPressed()) continue;
				
				if(buttons.get(i).isPressed()) {
					shapes.setColor(new Color(0, 0, 0, .5f));
				}else {
					shapes.setColor(new Color(0, 0, 0, .25f));
				}
				
				Vector2D screenPosition = cam.worldPosToScreenPos(buttons.get(i).getPosition());
				Vector2D screenSize = cam.worldSizeToScreenSize(buttons.get(i).getSize());
				
				if(buttons.get(i).isCircle()) {
					shapes.circle(
							screenPosition.getX(), 
							screenPosition.getY(), 
							screenSize.getLength() / 2);
				}else {
					shapes.rect(
							screenPosition.getX() - buttons.get(i).getSize().getX() / 2, 
							screenPosition.getY() - buttons.get(i).getSize().getY() / 2, 
							screenSize.getX(), 
							screenSize.getY());
				}
				
				
			}
		}

		shapes.end();
		Gdx.gl.glDisable(GL20.GL_BLEND);
		
	}

}
