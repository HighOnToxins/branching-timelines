package ld50.game.renderer;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import ld50.game.Main;
import ld50.game.state.Background;
import ld50.game.util.Util;
import ld50.game.util.objects.Camera;
import ld50.game.util.objects.Vector2D;

public class BackgroundRender {
	
	//fields
	private Background backState;
	
	private Camera cam;
	
	private Texture structure;

	public BackgroundRender(Background backState, Camera cam) {
		this.backState = backState;
		this.cam = cam;
		
		structure = Util.rec.structure;
	}

	//draw background
	public void draw(SpriteBatch batch, ShapeRenderer shapes) {
		
		Util.draw.box(shapes, new Vector2D(), Util.window.size, new Color(.6f, .6f, .7f, 1f));
		
		drawBackground(batch, shapes);
		drawLine(shapes);
		drawTime(batch, shapes);
	}
	
	private void drawLine(ShapeRenderer shapes) {

		Gdx.gl.glEnable(GL20.GL_BLEND);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		shapes.begin(ShapeType.Filled);

		Vector2D start = cam.worldPosToScreenPos(Util.window.size.scale(1/2f)).setX(0);
		Vector2D end = cam.worldPosToScreenPos(Util.window.size.scale(1/2f)).setX(Util.window.size.getX());
		shapes.setColor(new Color(0, 0, 0, .5f));
		shapes.rectLine(
				start.getX(), 
				start.getY(), 
				end.getX(), 
				end.getY(),
				cam.worldSizeToScreenSize(30));
			
		shapes.end();
		Gdx.gl.glDisable(GL20.GL_BLEND);
		
	}
	
	private void drawTime(SpriteBatch batch, ShapeRenderer shapes) {
		String scoreText = (int)backState.getFurthestTime() + "";
		float scoreWidth = scoreText.length() * 25;
		
		batch.begin();
		
		Main.font.getData().setScale(3f);
		Main.font.setColor(Color.BLACK);
		Main.font.draw(batch, "t", Util.window.size.getX() / 35, Util.window.size.getY() / 8);

		Main.font.setColor(Color.BLACK);
		Main.font.draw(batch, scoreText, Util.window.size.getX() - Util.window.size.getX() / 20 - scoreWidth, Util.window.size.getY() / 8);
		
		batch.end();
		shapes.begin(ShapeType.Filled);

		Vector2D start = new Vector2D(80, 65);
		Vector2D end = new Vector2D(Util.window.size.getX() - Util.window.size.getX() / 10 - scoreWidth, 65);
		shapes.setColor(Color.BLACK);
		shapes.rectLine(
				start.getX(), 
				start.getY(), 
				end.getX(), 
				end.getY(),
				10);
		shapes.triangle(
				end.getX() + 50, end.getY(), 
				end.getX(), end.getY() - 25, 
				end.getX(), end.getY() + 25);
			
		shapes.end();
	}
	
	private void drawBackground(SpriteBatch batch, ShapeRenderer shapes) {
		batch.begin();
		Util.draw.drawImage(
				new Vector2D(),
				batch, shapes, 
				structure,
				Util.window.pixelSize);
		batch.end();
	}
	
}
