/* -  -  -  -  -  Main method in "DesktopLauncher" should look like this  -  -  -  -  -  
		Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
		Main main = new Main();
		
		//setting title
		config.setTitle("LD50");
		
		//Setting size
		config.setWindowedMode((int)Main.size.getX(), (int)Main.size.getY());
		
		//setting FPS
		config.setForegroundFPS(60);
		config.setIdleFPS(30);
		
		//setting boolean variables
//		config.setFullscreenMode(Gdx.graphics.getDisplayMode());
		config.setResizable(true); 

		new Lwjgl3Application(main, config);
*/

package ld50.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.FitViewport;

import ld50.game.systems.GameSystemManager;
import ld50.game.util.Util;
import ld50.game.util.objects.Vector2D;

public class Main extends ApplicationAdapter {
	
	//variables
	public static Vector2D getMouseCords(Vector2D vec){
		Vector2D v = Vector2D.sub(vec, exSize).scale((float)(1/scale)); 
		return v.setY(Util.window.size.getY() - v.getY());
	}
	
	//for graphics
	private SpriteBatch batch;
	private ShapeRenderer shapes;
	
	public static BitmapFont font;
	
	//handling states
	private GameSystemManager GSM;
	
	public void create () {
		//setting graphics
		batch = new SpriteBatch();
		shapes = new ShapeRenderer();
		
		//setting fonts
		font = new BitmapFont(Gdx.files.internal("fonts/font.fnt"));
		
		//resources
		Util.rec.load();
		
		//setting states
		GSM = new GameSystemManager();
	}

	//called once per frame
	public void render () {
		//setting black bars
		fit();
						
		//update
		GSM.update();

		//drawing
		GSM.draw(batch, shapes); //drawing
	}
	
	//fit game to screen (adding black bars)
	private static double scale;
	private static Vector2D exSize = new Vector2D();
	
	private void fit(){
		//getting shadow size
		double widthScale = Gdx.graphics.getWidth() / (float)Util.window.size.getX();
		double heightScale= Gdx.graphics.getHeight()/ (float)Util.window.size.getY();
		exSize = new Vector2D();
		
		scale = Math.min(widthScale, heightScale);
		if(scale == heightScale)	exSize = exSize.setX((int) ((Gdx.graphics.getWidth() - Util.window.size.getX() *scale) / 2.));
		else						exSize = exSize.setY((int) ((Gdx.graphics.getHeight()- Util.window.size.getY()*scale) / 2.));
		
		//remove screen color
		Gdx.gl.glClearColor(0, 0, 0, 0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		//setting view port to screen and restore stages viewport
		Stage stage = new Stage(new FitViewport(Util.window.size.getX(), Util.window.size.getY()));
		Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		stage.getViewport().update(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), true);
	}
	
	//called when application is exited
	public void dispose () {
		batch.dispose();
		shapes.dispose();
	}
}
